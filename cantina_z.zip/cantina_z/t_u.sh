#!/bin/sh

cat /dev/ttyUSB0 > ./out_file.txt


