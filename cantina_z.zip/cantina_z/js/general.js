$(document).ready(function () {
    console.log("ready!");
    $('.datepicker').datepicker({
        format: 'dd/mm/yyyy',
        startDate: '-3d'
    });
});