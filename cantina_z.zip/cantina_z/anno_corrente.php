<!DOCTYPE html>
<html lang="en">
   <head>
        <?php include 'config.php'; ?>
        <?php include 'css_js.php'; ?>
    </head>
    <body>
        <?php
        include "nav.php";
        ?>
anno_corrente
    </body>
</html>