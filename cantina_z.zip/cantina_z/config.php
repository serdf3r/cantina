<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cantina";




//$conn->close();
?>